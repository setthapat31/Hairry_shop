/**
 * Google Apps Script (backend ตระกูล Google) สำหรับร้านแชมพู
 * วิธีใช้: เปิด Google Sheet ใหม่ > Extensions > Apps Script > วางโค้ดนี้
 * แล้วรันฟังก์ชัน setup() 1 ครั้ง จากนั้น Deploy > New deployment > Web app
 * (Execute as: Me / Who has access: Anyone)
 */

const SHEET_PRODUCTS = 'Products';
const SHEET_ORDERS = 'Orders';

// สร้างชีตทั้งหมดอัตโนมัติ พร้อมสินค้าตัวอย่าง 2 SKUs
function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  let p = ss.getSheetByName(SHEET_PRODUCTS) || ss.insertSheet(SHEET_PRODUCTS);
  p.clear();
  p.getRange(1, 1, 3, 6).setValues([
    ['sku', 'name', 'price', 'stock', 'image', 'description'],
    ['SHP-001', 'แชมพูอโลเวร่า สูตรอ่อนโยน', 189, 50, 'images/shp-001.jpg', 'ล้างหนังศีรษะสะอาด ไม่แห้งตึง ขนาด 300 มล.'],
    ['SHP-002', 'แชมพูมะกรูด ลดผมร่วง', 219, 40, 'images/shp-002.jpg', 'สกัดมะกรูด บำรุงรากผม ขนาด 300 มล.']
  ]);
  p.setFrozenRows(1);
  p.getRange(1, 1, 1, 6).setFontWeight('bold').setBackground('#DFF3EC');

  let o = ss.getSheetByName(SHEET_ORDERS) || ss.insertSheet(SHEET_ORDERS);
  o.clear();
  o.getRange(1, 1, 1, 10).setValues([[
    'timestamp', 'order_id', 'customer', 'phone', 'address',
    'sku', 'product', 'qty', 'total', 'status'
  ]]);
  o.setFrozenRows(1);
  o.getRange(1, 1, 1, 10).setFontWeight('bold').setBackground('#DFF3EC');
  o.getRange('J2:J').setDataValidation(
    SpreadsheetApp.newDataValidation().requireValueInList(['new', 'packed', 'shipped'], true).build()
  );

  // ใบหยิบสินค้า: รวมจำนวนที่ต้องหยิบของออเดอร์สถานะ new
  let pick = ss.getSheetByName('PickList') || ss.insertSheet('PickList');
  pick.clear();
  pick.getRange('A1').setFormula(
    '=IFERROR(QUERY(Orders!A1:J,"select F, G, sum(H) where J = \'new\' group by F, G label sum(H) \'จำนวนที่ต้องหยิบ\'",1),"ยังไม่มีออเดอร์ใหม่")'
  );

  // ใบปะหน้า/ใบแพ็ค: ใส่ order_id ที่ B1
  let slip = ss.getSheetByName('PackingSlip') || ss.insertSheet('PackingSlip');
  slip.clear();
  slip.getRange('A1').setValue('Order ID');
  slip.getRange('B1').setValue('(ใส่เลขออเดอร์ที่นี่)').setBackground('#FFF3C4');
  slip.getRange('A3').setValue('ผู้รับ');
  slip.getRange('B3').setFormula('=IFERROR(INDEX(FILTER(Orders!C:C,Orders!B:B=B1),1),"")');
  slip.getRange('A4').setValue('โทร');
  slip.getRange('B4').setFormula('=IFERROR(INDEX(FILTER(Orders!D:D,Orders!B:B=B1),1),"")');
  slip.getRange('A5').setValue('ที่อยู่');
  slip.getRange('B5').setFormula('=IFERROR(INDEX(FILTER(Orders!E:E,Orders!B:B=B1),1),"")');
  slip.getRange('A7').setValue('รายการสินค้า (SKU / สินค้า / จำนวน)');
  slip.getRange('A8').setFormula('=IFERROR(FILTER({Orders!F:F,Orders!G:G,Orders!H:H},Orders!B:B=B1),"")');
  slip.getRange('A3:A7').setFontWeight('bold');

  const first = ss.getSheetByName('Sheet1');
  if (first && ss.getSheets().length > 1) ss.deleteSheet(first);
}

// ส่งรายการสินค้าให้หน้าเว็บ (GET)
function doGet() {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_PRODUCTS);
  const [head, ...rows] = sh.getDataRange().getValues();
  const items = rows.filter(r => r[0]).map(r => {
    const obj = {};
    head.forEach((h, i) => obj[h] = r[i]);
    return obj;
  });
  return json({ ok: true, products: items });
}

// รับออเดอร์จากหน้าเว็บ (POST) body = {customer, phone, address, items:[{sku, qty}]}
function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const data = JSON.parse(e.postData.contents);
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const ps = ss.getSheetByName(SHEET_PRODUCTS);
    const os = ss.getSheetByName(SHEET_ORDERS);
    const prod = ps.getDataRange().getValues();
    const orderId = 'ORD-' + Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyMMdd-HHmmss');

    const lines = [];
    for (const it of data.items) {
      const qty = Number(it.qty);
      const idx = prod.findIndex((r, i) => i > 0 && r[0] === it.sku);
      if (idx < 0 || !(qty > 0)) continue;
      if (prod[idx][3] < qty) return json({ ok: false, error: 'สต็อกไม่พอ: ' + it.sku });
      lines.push({ idx, qty });
    }
    if (!lines.length) return json({ ok: false, error: 'ไม่มีสินค้าในตะกร้า' });

    lines.forEach(({ idx, qty }) => {
      const r = prod[idx];
      os.appendRow([
        new Date(), orderId, data.customer, "'" + data.phone, data.address,
        r[0], r[1], qty, qty * r[2], 'new'
      ]);
      ps.getRange(idx + 1, 4).setValue(r[3] - qty); // ตัดสต็อก
    });
    return json({ ok: true, orderId });
  } catch (err) {
    return json({ ok: false, error: String(err) });
  } finally {
    lock.releaseLock();
  }
}

function json(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
