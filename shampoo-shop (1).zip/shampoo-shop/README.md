# ร้านแชมพู (Landing page + Google Sheets + Vercel)

โครงสร้าง
```
shampoo-shop/
├── index.html            หน้าเว็บขายแชมพู (2 SKUs)
├── images/               ใส่รูปสินค้า shp-001.jpg, shp-002.jpg
├── data/products.csv     ข้อมูลสินค้า (สำรอง/นำเข้าชีต)
└── apps-script/Code.gs   backend บน Google Apps Script
```

## ขั้นตอน
1. สร้าง Google Sheet ใหม่ > Extensions > Apps Script > วางโค้ดจาก `apps-script/Code.gs`
2. เลือกฟังก์ชัน `setup` แล้วกด Run (อนุญาตสิทธิ์) จะได้ชีต Products, Orders, PickList, PackingSlip
3. Deploy > New deployment > Web app (Execute as: Me, Access: Anyone) แล้วคัดลอก URL
4. วาง URL ที่ `API_URL` ใน `index.html`
5. ใส่รูปสินค้าในโฟลเดอร์ `images/`
6. อัปโหลดทั้งโฟลเดอร์ขึ้น GitHub แล้ว Import repo ใน Vercel (Framework: Other) เพื่อได้โดเมน

## ใช้งานหยิบ/แพ็คสินค้า
- `PickList` สรุปจำนวนที่ต้องหยิบของออเดอร์สถานะ `new`
- `PackingSlip` ใส่เลขออเดอร์ในช่อง B1 จะแสดงชื่อ ที่อยู่ และรายการสินค้าสำหรับแพ็ค/ใบปะหน้า
- เปลี่ยนสถานะในชีต Orders เป็น `packed` / `shipped`
